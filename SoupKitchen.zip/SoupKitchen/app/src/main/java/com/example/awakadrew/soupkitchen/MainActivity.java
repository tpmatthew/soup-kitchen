package com.example.awakadrew.soupkitchen;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    public Button about, contact, volunteer, donateItem, donateMoney; // The buttons on the main menu that might be clicked on.
    public Button button;
    Intent next; // Intent next is made to move activity to activity.

    // The method where a button is clicked on to send it to a new activity.
    public void onClick(View v){
        // Switch-case for the different activities.
        switch (v.getId()) {

            case R.id.about:
                next = new Intent(this,.class);
                break;

            case R.id.contact:
                next = new Intent(this,.class);
                break;

            case R.id.volunteer:
                next = new Intent(this,.class);
                break;

            case R.id.donateItems:
                next = new Intent(this,.class);
                break;

            case R.id.donateMoney:
                next = new Intent(this,.class);
                break;

            default:
                break;
        }

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //the buttons and setting them for onClick method.
        about = (Button)findViewById(R.id.about);
        about.setOnClickListener(this);
        contact = (Button)findViewById(R.id.contact);
        contact.setOnClickListener(this);
        volunteer = (Button)findViewById(R.id.volunteer);
        volunteer.setOnClickListener(this);
        donateItem = (Button)findViewById(R.id.donateItems);
        donateItem.setOnClickListener(this);
        donateMoney = (Button)findViewById(R.id.donateMoney);
        donateMoney.setOnClickListener(this);
    }
}
